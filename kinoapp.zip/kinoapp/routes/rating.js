let logger = require("../logger/logger").logger;
let checker = require("../authenticate");
let admin = require("../check_admin");
const Rating = require('../database/Rating');

module.exports = function(router) {
    router.get("/", checker, admin, async (req, res) => {
        result = await Rating.find();
        res.json(result);
        logger.debug((req.method, Date(), result));
    });

    router.post("/", checker, async (req, res) => {
        result = await Rating.create(req.body);
        res.json(result);
        logger.debug((req.method, Date(), result));
    });

    router.get("/:id", checker, async (req, res) => {
        result = await Rating.findById(req.params.id);
        res.json(result);
        logger.debug((req.method, Date(), result));
    });

    router.put("/:id", checker, async (req, res) => {
        if (req.session.id == req.body.user) {
            result = await Rating.findByIdAndUpdate(req.params.id, req.body);
            res.json(result);
        } else {
            res.send("Нет доступа");
        }
        logger.debug((req.method, Date(), result));
    });

    router.delete("/:id", checker, async (req, res) => {
        if (req.session.id == req.body.user) {
            result = await Rating.findByIdAndDelete(req.params.id);
        } else {
            res.send("Нет доступа");
        }
        logger.debug((req.method, Date(), result));
    });

    return router;
}

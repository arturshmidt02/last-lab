const express = require('express');
const router = express();
const bcrypt = require("bcrypt");
const categoryRoute = require('./categories');
const countryRoute = require('./countries');
const filmRoute = require('./films');
const userRoute = require('./users');
const User = require("../database/User");
router.post('/signup', async (req, res) => {
    try {
        const user = await User.create(req.body);
        res.json(user);
    } catch(e) {
        res.json({ message: e });
    }
    console.log(req.body);
});
router.get('/login', async (req, res) => {
    res.send("Войдите");
});
router.post('/login', async (req, res) => {
    const user = await User.findOne({email: req.body.email}, function(err, user) {
        if (err) {
            res.json({
                status: 0,
                message: err
            });
        }
        if (!user) {
            res.json({
                status: 0,
                msg: "не найдено"
            });
        }
    });
    if (user) {
        result = bcrypt.compareSync(req.body.password, user.password);
        if (result == true) {
            req.session.email = req.body.email;
            req.session.role = user.role;
            req.session.id = user._id;
        }
    }
    res.send('Здравствуйте');
});

router.get('/logout', (req, res) => {
    req.session.destroy()
    res.redirect('login');
});
router.use('/user', userRoute);
router.use('/films', filmRoute);
router.use('/categories', categoryRoute);
router.use('/countries', countryRoute);
module.exports = router
